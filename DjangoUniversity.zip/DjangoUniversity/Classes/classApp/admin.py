from django.contrib import admin

# To register this model, we have to first import it into this file.
from .models import djangoClasses

# This line of code is to tell the admin software how to manage
# the 'djangoClasses' module.
admin.site.register(djangoClasses)

