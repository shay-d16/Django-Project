from django.db import models

class djangoClasses(models.Model):
    title = models.CharField(max_length=60)
    course_number = models.IntegerField()
    instructor_name = models.CharField(max_length=60)
    duration = models.FloatField()

    # Now that that model has been created, and its default manager
    # "djangoClasses.object(1)" along with it, let's rename it
    # 'objects'.
    objects = models.Manager()

    # This will ensure that the object is displayed as the 'title'
    # of the class rather than just "djangoClasses.object(1)".
    def __str__(self):
        return self.title

